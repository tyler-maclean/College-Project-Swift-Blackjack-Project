//
//  GameScreenViewController.swift
//  Blackjack Project
//
//  Created by Tyler Maclean on 2018-04-06.
//  Copyright © 2018 DTA. All rights reserved.
//

import UIKit
class GameScreenViewController: UIViewController {

    
    @IBOutlet weak var playerAmount: UILabel!
    @IBOutlet weak var houseAmount: UILabel!
    @IBOutlet weak var staybutton: UIButton!
    @IBOutlet weak var hitbutton: UIButton!
    @IBOutlet weak var playerPoints: UILabel!
    @IBOutlet weak var globaltest2: UILabel!
    @IBOutlet weak var houseCard1: UILabel!
    @IBOutlet weak var houseCard2: UILabel!
    @IBOutlet weak var playerCard1: UILabel!
    @IBOutlet weak var playerCard2: UILabel!
    @IBOutlet weak var startbutton: UIButton!
    @IBOutlet weak var playerCard3: UILabel!
    var cards = [1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10]
    var shuffled = [Int]();
    var currentCardIndex = 0
    var bust = 0
    var housebust = 0
    var playerpoints = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        globaltest2.text = "\(playername)"
       

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func globalbuttontest(_ sender: UIButton) {
        startbutton.isHidden = true;
        hitbutton.isHidden = false;
        staybutton.isHidden = false;

        for _ in 0..<cards.count
        {
            let rand = Int(arc4random_uniform(UInt32(cards.count)))
            
            shuffled.append(cards[rand])
            
        }
        currentCardIndex = 0
        houseCard1.text = "\(shuffled[currentCardIndex])"
        currentCardIndex = currentCardIndex + 1
        houseCard2.text = "\(shuffled[currentCardIndex])"
        currentCardIndex = currentCardIndex + 1
        playerCard1.text = "\(shuffled[currentCardIndex])"
        currentCardIndex = currentCardIndex + 1
        playerCard2.text = "\(shuffled[currentCardIndex])"
        
        housebust = housebust + shuffled[0] + shuffled[1]
        bust = bust + shuffled[2] + shuffled[3]
        
        playerAmount.text = "\(bust)"
        houseAmount.text = "\(housebust)"



    }
    
    @IBAction func hitbuttonPressed(_ sender: UIButton) {
        currentCardIndex = currentCardIndex + 1
        bust = bust + shuffled[currentCardIndex]
        playerCard3.text = "\(shuffled[currentCardIndex])"
        playerCard3.isHidden = false;
        playerAmount.text = "\(bust)"
        
        if bust > 21 {
            playerpoints = playerpoints - 50
            playerPoints.text = "\(playerpoints)"
            let alert = UIAlertController(title: "The house wins!", message: "The house wins. You lost 50 points. Press the button below to start over", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil ))
            
            self.present(alert, animated: true, completion: nil)

                currentCardIndex = 0
                shuffled.removeAll()
                houseCard1.text = "Card"
                houseCard2.text = "Card"
                playerCard1.text = "Card"
                playerCard2.text = "Card"
                playerCard3.text = "Card"
                bust = 0
                housebust = 0
                startbutton.isHidden = false;
                hitbutton.isHidden = true;
                staybutton.isHidden = true;
                playerCard3.isHidden = true;

        }
        
    }
    
    @IBAction func staybuttonPressed(_ sender: UIButton) {
        while housebust < bust {
            currentCardIndex = currentCardIndex + 1
            housebust = housebust + shuffled[currentCardIndex]
            houseAmount.text = "\(housebust)"
        }
        
        if housebust >= bust && housebust <= 21 {
            playerpoints = playerpoints - 50
            playerPoints.text = "\(playerpoints)"
            let alert = UIAlertController(title: "The house wins!", message: "The house wins. You lost 50 points. Press the button below to start over", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil ))
            
            self.present(alert, animated: true, completion: nil)
            
            currentCardIndex = 0
            shuffled.removeAll()
            houseCard1.text = "Card"
            houseCard2.text = "Card"
            playerCard1.text = "Card"
            playerCard2.text = "Card"
            playerCard3.text = "Card"
            bust = 0
            housebust = 0
            startbutton.isHidden = false;
            hitbutton.isHidden = true;
            staybutton.isHidden = true;
            playerCard3.isHidden = true;
            
        }

        if housebust > 21 {
            playerpoints = playerpoints + 50
            playerPoints.text = "\(playerpoints)"
            let alert = UIAlertController(title: "You win!", message: "You won. You got 50 points. Press the button below to start over", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil ))
            
            self.present(alert, animated: true, completion: nil)
            
            currentCardIndex = 0
            shuffled.removeAll()
            houseCard1.text = "Card"
            houseCard2.text = "Card"
            playerCard1.text = "Card"
            playerCard2.text = "Card"
            playerCard3.text = "Card"
            bust = 0
            housebust = 0
            startbutton.isHidden = false;
            hitbutton.isHidden = true;
            staybutton.isHidden = true;
            playerCard3.isHidden = true;
            
        }

    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
