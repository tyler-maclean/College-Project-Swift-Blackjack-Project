//
//  ViewController.swift
//  Blackjack Project
//
//  Created by Tyler Maclean on 2018-04-06.
//  Copyright © 2018 DTA. All rights reserved.
//

import UIKit
var playername = ""
class ViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

